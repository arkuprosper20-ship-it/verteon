(function () {
  const vscode = acquireVsCodeApi();

  const chatEl = document.getElementById('chat');
  const inputEl = document.getElementById('input');
  const sendBtn = document.getElementById('send-btn');
  const stopBtn = document.getElementById('stop-btn');
  const newChatBtn = document.getElementById('new-chat-btn');
  const settingsBtn = document.getElementById('settings-btn');
  const statusDot = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');
  const approvalContainer = document.getElementById('approval-container');

  let currentAssistantBubble = null;
  let currentAssistantText = '';

  function escapeHtml(s) {
    return s
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function scrollToBottom() {
    chatEl.scrollTop = chatEl.scrollHeight;
  }

  function addUserMessage(text) {
    const div = document.createElement('div');
    div.className = 'msg user-msg';
    div.innerHTML = `<div class="msg-label">You</div><div class="msg-body">${escapeHtml(text)}</div>`;
    chatEl.appendChild(div);
    scrollToBottom();
  }

  function startAssistantMessage() {
    currentAssistantText = '';
    const div = document.createElement('div');
    div.className = 'msg assistant-msg';
    div.innerHTML = `<div class="msg-label">Agent</div><div class="msg-body"></div>`;
    chatEl.appendChild(div);
    currentAssistantBubble = div.querySelector('.msg-body');
    scrollToBottom();
  }

  function appendAssistantDelta(delta) {
    if (!currentAssistantBubble) startAssistantMessage();
    currentAssistantText += delta;
    currentAssistantBubble.textContent = currentAssistantText;
    scrollToBottom();
  }

  function finishAssistantMessage() {
    currentAssistantBubble = null;
  }

  function addActivity(activity) {
    const div = document.createElement('div');
    let icon = '\u2022';
    let cls = 'activity';
    if (activity.kind === 'tool_start') { icon = '\u2192'; cls += ' activity-running'; }
    else if (activity.kind === 'tool_end') { icon = activity.success === false ? '\u2717' : '\u2713'; cls += activity.success === false ? ' activity-error' : ' activity-ok'; }
    else if (activity.kind === 'error') { icon = '\u2717'; cls += ' activity-error'; }
    else if (activity.kind === 'command_output') { cls += ' activity-output'; icon = ''; }
    else if (activity.kind === 'message') { cls += ' activity-note'; icon = 'i'; }
    div.className = cls;
    if (activity.kind === 'command_output') {
      div.innerHTML = `<pre>${escapeHtml(activity.text)}</pre>`;
    } else {
      div.innerHTML = `<span class="activity-icon">${icon}</span><span>${escapeHtml(activity.text)}</span>`;
    }
    chatEl.appendChild(div);
    scrollToBottom();
  }

  function addSystemNote(text, isError) {
    const div = document.createElement('div');
    div.className = 'system-note' + (isError ? ' system-error' : '');
    div.textContent = text;
    chatEl.appendChild(div);
    scrollToBottom();
  }

  function setRunning(running) {
    sendBtn.classList.toggle('hidden', running);
    stopBtn.classList.toggle('hidden', !running);
    inputEl.disabled = running;
  }

  function renderApproval(approvalId, request) {
    const div = document.createElement('div');
    div.className = 'approval-card';
    div.innerHTML = `
      <div class="approval-title">${escapeHtml(request.title)}</div>
      <div class="approval-row"><span class="approval-key">Will run:</span> <code>${escapeHtml(request.whatWillRun)}</code></div>
      <div class="approval-row"><span class="approval-key">Why:</span> ${escapeHtml(request.why)}</div>
      <div class="approval-row"><span class="approval-key">Effect:</span> ${escapeHtml(request.potentialEffect)}</div>
      <div class="approval-buttons">
        <button class="approve-btn">Approve</button>
        <button class="reject-btn">Reject</button>
      </div>
    `;
    div.querySelector('.approve-btn').addEventListener('click', () => {
      vscode.postMessage({ type: 'approvalResponse', approvalId, approved: true });
      div.remove();
      addSystemNote(`Approved: ${request.title}`);
    });
    div.querySelector('.reject-btn').addEventListener('click', () => {
      vscode.postMessage({ type: 'approvalResponse', approvalId, approved: false });
      div.remove();
      addSystemNote(`Rejected: ${request.title}`, true);
    });
    approvalContainer.appendChild(div);
    scrollToBottom();
  }

  function send() {
    const text = inputEl.value.trim();
    if (!text) return;
    inputEl.value = '';
    vscode.postMessage({ type: 'sendMessage', text });
  }

  sendBtn.addEventListener('click', send);
  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  });
  stopBtn.addEventListener('click', () => vscode.postMessage({ type: 'stopAgent' }));
  newChatBtn.addEventListener('click', () => vscode.postMessage({ type: 'newChat' }));
  settingsBtn.addEventListener('click', () => vscode.postMessage({ type: 'openSettings' }));

  window.addEventListener('message', (event) => {
    const msg = event.data;
    switch (msg.type) {
      case 'status':
        statusDot.className = 'status-dot ' + (msg.connected ? 'status-ok' : 'status-error');
        statusText.textContent = msg.connected ? `${msg.model}` : msg.message;
        statusText.title = msg.message;
        break;
      case 'userMessage':
        addUserMessage(msg.text);
        break;
      case 'agentStart':
        setRunning(true);
        break;
      case 'textDelta':
        appendAssistantDelta(msg.delta);
        break;
      case 'activity':
        addActivity(msg.activity);
        break;
      case 'approvalRequest':
        renderApproval(msg.approvalId, msg.request);
        break;
      case 'agentDone':
        finishAssistantMessage();
        setRunning(false);
        break;
      case 'agentStopped':
        finishAssistantMessage();
        setRunning(false);
        addSystemNote(msg.reason, true);
        break;
      case 'error':
        setRunning(false);
        addSystemNote(msg.text, true);
        break;
      case 'cleared':
        chatEl.innerHTML = '';
        approvalContainer.innerHTML = '';
        break;
    }
  });

  vscode.postMessage({ type: 'ready' });
})();

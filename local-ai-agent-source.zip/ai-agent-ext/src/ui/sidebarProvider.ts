import * as vscode from 'vscode';
import { ActivityEvent, ApprovalRequest, ChatMessage } from '../types';
import { getConfig } from '../config/configuration';
import { createProvider } from '../providers/providerFactory';
import { buildToolRegistry } from '../tools/toolRegistry';
import { runAgentLoop } from '../agent/agentLoop';
import { buildSystemPrompt, getActiveEditorContext } from '../context/contextManager';
import { detectProjectSummary } from '../tools/projectTools';
import { MemoryStore } from '../memory/memoryStore';
import { logger } from '../logging/logger';
import { killAllProcesses } from '../tools/terminalTools';

interface PendingApproval {
  resolve: (approved: boolean) => void;
}

export class SidebarProvider implements vscode.WebviewViewProvider {
  public static readonly viewType = 'aiAgent.chatView';
  private view?: vscode.WebviewView;
  private history: ChatMessage[] = [];
  private cancellationToken = { isCancelled: false };
  private isRunning = false;
  private pendingApprovals = new Map<string, PendingApproval>();
  private approvalCounter = 0;
  private memory: MemoryStore;

  constructor(private readonly extensionUri: vscode.Uri, private readonly context: vscode.ExtensionContext) {
    this.memory = new MemoryStore(context);
  }

  resolveWebviewView(webviewView: vscode.WebviewView): void {
    this.view = webviewView;
    webviewView.webview.options = { enableScripts: true, localResourceRoots: [this.extensionUri] };
    webviewView.webview.html = this.getHtml(webviewView.webview);

    webviewView.webview.onDidReceiveMessage(async (msg) => {
      switch (msg.type) {
        case 'ready':
          this.postStatus();
          break;
        case 'sendMessage':
          await this.handleUserMessage(msg.text);
          break;
        case 'stopAgent':
          this.cancellationToken.isCancelled = true;
          break;
        case 'approvalResponse':
          this.resolveApproval(msg.approvalId, msg.approved);
          break;
        case 'newChat':
          this.history = [];
          this.post({ type: 'cleared' });
          break;
        case 'refreshModels':
          await this.handleRefreshModels();
          break;
        case 'openSettings':
          vscode.commands.executeCommand('workbench.action.openSettings', 'agent.');
          break;
        case 'checkHealth':
          await this.postStatus();
          break;
      }
    });
  }

  private post(msg: any) {
    this.view?.webview.postMessage(msg);
  }

  private async postStatus() {
    const config = getConfig();
    const provider = createProvider(config);
    const health = await provider.healthCheck().catch((e) => ({ ok: false, message: String(e) }));
    this.post({ type: 'status', connected: health.ok, message: health.message, model: config.model, provider: config.provider });
  }

  private async handleRefreshModels() {
    const config = getConfig();
    const provider = createProvider(config);
    try {
      const models = await provider.listModels();
      this.post({ type: 'models', models });
    } catch (err: any) {
      this.post({ type: 'models', models: [], error: err.message ?? String(err) });
    }
  }

  public async runSlashCommand(kind: 'explain' | 'fix' | 'refactor' | 'fixErrors' | 'inspect', text?: string) {
    await this.focus();
    const prompts: Record<string, string> = {
      explain: 'Explain the currently selected code.',
      fix: 'Fix the currently selected code (or the active file if nothing is selected).',
      refactor: 'Refactor the currently selected code for clarity and maintainability, preserving behavior.',
      fixErrors: 'Find and fix all current errors/diagnostics in this project. Run relevant checks (build/test/lint) to verify.',
      inspect: 'Inspect this project and give me a concise summary of its structure, framework, and how to run/test it.',
    };
    await this.handleUserMessage(text ?? prompts[kind]);
  }

  public async focus() {
    await vscode.commands.executeCommand('workbench.view.extension.aiAgentContainer');
  }

  private getWorkspaceRoot(): string | null {
    const folders = vscode.workspace.workspaceFolders;
    if (!folders || folders.length === 0) return null;
    return folders[0].uri.fsPath;
  }

  private async handleUserMessage(text: string) {
    if (!text || !text.trim()) return;
    if (this.isRunning) {
      this.post({ type: 'error', text: 'The agent is still working on the previous request. Stop it first or wait.' });
      return;
    }
    const workspaceRoot = this.getWorkspaceRoot();
    if (!workspaceRoot) {
      this.post({ type: 'error', text: 'No workspace folder is open. Open a folder to use the AI agent.' });
      return;
    }

    const config = getConfig();
    const provider = createProvider(config);
    const health = await provider.healthCheck();
    if (!health.ok) {
      this.post({ type: 'error', text: health.message });
      return;
    }

    this.isRunning = true;
    this.cancellationToken = { isCancelled: false };
    this.post({ type: 'userMessage', text });
    this.post({ type: 'agentStart' });

    try {
      const tools = buildToolRegistry(config);
      let projectSummary: string | undefined;
      try {
        projectSummary = await detectProjectSummary({
          workspaceRoot,
          requestApproval: async () => true,
          emitActivity: () => {},
          cancellationToken: this.cancellationToken,
        });
      } catch (e) {
        logger.debug(`Could not build project summary: ${e}`);
      }
      const editorCtx = getActiveEditorContext(workspaceRoot);
      const mem = config.enableProjectMemory ? this.memory.get() : undefined;
      const systemPrompt = buildSystemPrompt(projectSummary, mem, editorCtx);

      if (this.history.length === 0 || this.history[0].role !== 'system') {
        this.history.unshift({ role: 'system', content: systemPrompt });
      } else {
        this.history[0] = { role: 'system', content: systemPrompt };
      }
      this.history.push({ role: 'user', content: text });

      const result = await runAgentLoop(
        this.history,
        {
          provider,
          tools,
          workspaceRoot,
          maxIterations: config.maxAgentIterations,
          requestApproval: config.requireCommandApproval || config.requireFileApproval ? this.requestApproval.bind(this) : async () => true,
          emitActivity: (activity: ActivityEvent) => this.post({ type: 'activity', activity }),
          onTextDelta: (delta: string) => this.post({ type: 'textDelta', delta }),
        },
        this.cancellationToken
      );

      this.history = result.history;

      if (result.stoppedReason === 'cancelled') {
        this.post({ type: 'agentStopped', reason: 'Stopped by user.' });
      } else if (result.stoppedReason === 'error') {
        this.post({ type: 'agentStopped', reason: 'An error occurred. See the "AI Agent" output channel for details.' });
      } else if (result.stoppedReason === 'max_iterations') {
        this.post({ type: 'agentStopped', reason: `Reached the iteration limit (${config.maxAgentIterations}).` });
      } else {
        this.post({ type: 'agentDone' });
      }

      if (config.enableProjectMemory && result.toolsUsed.length > 0) {
        const uniqueCommands = new Set<string>();
        for (const line of result.history) {
          if (line.role === 'tool' && line.content.startsWith('$ ')) {
            uniqueCommands.add(line.content.split('\n')[0].slice(2));
          }
        }
        for (const cmd of uniqueCommands) {
          await this.memory.addCommand(cmd);
        }
      }
    } catch (err: any) {
      logger.error('Agent run failed', err);
      this.post({ type: 'error', text: `Unexpected error: ${err.message ?? err}` });
    } finally {
      this.isRunning = false;
    }
  }

  private requestApproval(request: ApprovalRequest): Promise<boolean> {
    const config = getConfig();
    const isFileOp = /^(Write file|Create file|Delete file|Rename|Edit|Insert into|Edit active file)/.test(request.title);
    const needsApproval = isFileOp ? config.requireFileApproval : config.requireCommandApproval;
    if (!needsApproval && request.tier !== 'blocked') {
      return Promise.resolve(true);
    }
    const approvalId = `approval_${++this.approvalCounter}`;
    this.post({ type: 'approvalRequest', approvalId, request });
    return new Promise<boolean>((resolve) => {
      this.pendingApprovals.set(approvalId, { resolve });
    });
  }

  private resolveApproval(approvalId: string, approved: boolean) {
    const pending = this.pendingApprovals.get(approvalId);
    if (pending) {
      pending.resolve(approved);
      this.pendingApprovals.delete(approvalId);
    }
  }

  public stopAgent() {
    this.cancellationToken.isCancelled = true;
    killAllProcesses();
  }

  public async clearMemory() {
    await this.memory.clear();
    vscode.window.showInformationMessage('AI Agent: project memory cleared.');
  }

  private getHtml(webview: vscode.Webview): string {
    const scriptUri = webview.asWebviewUri(vscode.Uri.joinPath(this.extensionUri, 'media', 'main.js'));
    const styleUri = webview.asWebviewUri(vscode.Uri.joinPath(this.extensionUri, 'media', 'main.css'));
    const nonce = String(Date.now());
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}';" />
  <link href="${styleUri}" rel="stylesheet" />
  <title>AI Agent</title>
</head>
<body>
  <div id="app">
    <div id="header">
      <div id="header-left">
        <span id="agent-logo">&#9679;</span>
        <span id="agent-name">AI Agent</span>
      </div>
      <div id="header-right">
        <span id="status-dot" class="status-dot status-unknown"></span>
        <span id="status-text">checking...</span>
        <button id="settings-btn" title="Settings">&#9881;</button>
      </div>
    </div>
    <div id="chat"></div>
    <div id="approval-container"></div>
    <div id="input-area">
      <textarea id="input" placeholder="Ask the agent to inspect, edit, or fix something..." rows="2"></textarea>
      <div id="input-buttons">
        <button id="new-chat-btn" title="New chat">New</button>
        <button id="send-btn" title="Send">Send</button>
        <button id="stop-btn" title="Stop" class="hidden">Stop</button>
      </div>
    </div>
  </div>
  <script nonce="${nonce}" src="${scriptUri}"></script>
</body>
</html>`;
  }
}

# Local AI Agent

An agentic AI coding assistant for VS Code, powered by a locally hosted model via Ollama.
No cloud API key required for core operation.

## Requirements
- [Ollama](https://ollama.com) running locally (default `http://localhost:11434`)
- A pulled coding-capable model, e.g. `ollama pull qwen2.5-coder:7b`

## Usage
Open the "AI Agent" panel from the Activity Bar and describe a task. The agent will
inspect your project, read/edit files, run commands and tests, and iterate on failures
(up to `agent.maxAgentIterations`, default 5) — asking for approval before risky actions.

See `agent.*` settings to configure the Ollama URL, model, and approval behavior.

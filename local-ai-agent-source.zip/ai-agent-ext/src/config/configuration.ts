import * as vscode from 'vscode';

export interface AgentConfig {
  provider: 'ollama';
  ollamaUrl: string;
  model: string;
  temperature: number;
  maxContext: number;
  maxOutputTokens: number;
  commandTimeout: number;
  maxAgentIterations: number;
  requireCommandApproval: boolean;
  requireFileApproval: boolean;
  enableProjectMemory: boolean;
  enableGitTools: boolean;
  debugLogging: boolean;
}

export function getConfig(): AgentConfig {
  const c = vscode.workspace.getConfiguration('agent');
  return {
    provider: c.get('provider', 'ollama'),
    ollamaUrl: c.get('ollama.url', 'http://localhost:11434'),
    model: c.get('model', 'qwen2.5-coder:7b'),
    temperature: c.get('temperature', 0.2),
    maxContext: c.get('maxContext', 8192),
    maxOutputTokens: c.get('maxOutputTokens', 2048),
    commandTimeout: c.get('commandTimeout', 120000),
    maxAgentIterations: c.get('maxAgentIterations', 5),
    requireCommandApproval: c.get('requireCommandApproval', true),
    requireFileApproval: c.get('requireFileApproval', true),
    enableProjectMemory: c.get('enableProjectMemory', true),
    enableGitTools: c.get('enableGitTools', true),
    debugLogging: c.get('debugLogging', false),
  };
}
